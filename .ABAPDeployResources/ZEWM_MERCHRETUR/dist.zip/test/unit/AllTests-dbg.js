sap.ui.define([
	"CMR/ZEWM_MERCH_RETURN/test/unit/controller/Main.controller"
], function () {
	"use strict";
});